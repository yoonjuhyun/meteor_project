var require = meteorInstall({"lib":{"monglist.js":["meteor/mongo",function(require){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// lib/monglist.js                                                                   //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
var _mongo = require('meteor/mongo');                                                // 4
                                                                                     //
List = new _mongo.Mongo.Collection('List'); /**                                      // 6
                                             * Created by kimjungmin on 2016. 6. 5..
                                             */                                      //
                                                                                     //
                                                                                     //
List.insert({ name: "afds", tel: "010" });                                           // 8
                                                                                     //
List.insert({ name: "afds", tel: "010" });                                           // 11
///////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"main.js":["meteor/meteor",function(require){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// server/main.js                                                                    //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
var _meteor = require('meteor/meteor');                                              // 1
                                                                                     //
_meteor.Meteor.startup(function () {                                                 // 3
  // code to run on server at startup                                                //
});                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/monglist.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
